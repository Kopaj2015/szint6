Template.createCategory.helpers({
    categories: function() {
        return Categories.find({});
    }

});

Template.createCategory.events({
   'submit': function (event) {
       event.preventDefault();

       var name = event.target.name.value;

       if(name) {
           Method.call('addCategory', name);
       }

   }
});